<h2>Strona 2</h2>
<p>To jest zawartość strony 2.</p>
